import asyncio, json, sys, types, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "2base"))

import signal_analyzer as sa


def trade_msg(sym, trades):
    return {"arg": {"instType": "USDT-FUTURES", "channel": "trade", "instId": sym},
            "data": [{"ts": str(t[0]), "price": str(t[1]), "size": str(t[2]), "side": t[3], "tradeId": t[4]} for t in trades]}


def book_msg(sym, channel, action, seq, pseq, bids, asks, ts=1000):
    return {"arg": {"instType": "USDT-FUTURES", "channel": channel, "instId": sym},
            "action": action,
            "data": [{"ts": str(ts), "seq": seq, "pseq": pseq,
                      "bids": [[str(p), str(s)] for p, s in bids],
                      "asks": [[str(p), str(s)] for p, s in asks]}]}


class FakeWS:
    def __init__(self):
        self.sent = []

    async def send(self, payload):
        self.sent.append(json.loads(payload))


async def test_trade_dedupe():
    a = sa.OrderFlowAnalyzer("BTCUSDT")
    batch = [(1000, 100.0, 1.0, "buy", "1"), (1001, 100.1, 2.0, "sell", "2")]
    await a.handle_message(trade_msg("BTCUSDT", batch))
    await a.handle_message(trade_msg("BTCUSDT", batch))  # replay after reconnect
    assert len(a.trade_history) == 2, a.trade_history
    assert a.ws_diag["duplicate_trades"] == 2
    assert abs(a.level_delta[100.0] - 1.0) < 1e-9


async def test_sequence_gap_requests_resync():
    a = sa.OrderFlowAnalyzer("BTCUSDT")
    await a.handle_message(book_msg("BTCUSDT", "books", "snapshot", 10, None, [(100.0, 5)], [(101.0, 5)]))
    assert a.seq == 10 and not a.needs_resync
    await a.handle_message(book_msg("BTCUSDT", "books", "update", 11, 10, [(100.0, 6)], []))
    assert a.bids[100.0] == 6 and a.seq == 11 and not a.needs_resync
    await a.handle_message(book_msg("BTCUSDT", "books", "update", 20, 19, [(100.0, 9)], []))
    assert a.needs_resync, "sequence gap must request a resync"
    assert a.bids[100.0] == 6, "gapped update must not be applied"

    # snapshot-style channels keep working (pseq=0 -> full replace, no gap)
    b = sa.OrderFlowAnalyzer("ETHUSDT")
    await b.handle_message(book_msg("ETHUSDT", "books15", "update", 5, 0, [(10.0, 1)], [(11.0, 1)]))
    assert not b.needs_resync and b.bids[10.0] == 1


async def test_channel_tiering():
    m = sa.OrderFlowManager()
    assert m._book_channel() == "books15"
    assert m._focus_book_channel() == "books"
    assert m._symbols_per_connection("books15") == 13
    assert m._symbols_per_connection("books") == 5, m._symbols_per_connection("books")

    assert m.desired_book_channel("AUSDT") == "books15"
    m.mark_focus("AUSDT")
    assert m.desired_book_channel("AUSDT") == "books"

    # focus set is capped and dwell-protected against churn
    sa.SIGNAL_CONFIG["of_focus_symbols_max"] = 1
    m.mark_focus("BUSDT")
    assert m.desired_book_channel("BUSDT") == "books15", "dwell must block immediate eviction"
    m._focus_promoted_at["AUSDT"] = 0.0
    m.mark_focus("BUSDT")
    assert m.desired_book_channel("BUSDT") == "books"
    assert m.desired_book_channel("AUSDT") == "books15"
    sa.SIGNAL_CONFIG["of_focus_symbols_max"] = 40


async def test_ownership_prefers_desired_channel():
    m = sa.OrderFlowManager()
    m.mark_focus("BUSDT")
    m.groups[1] = {"symbols": {"AUSDT", "BUSDT"}, "created_at_ms": 1, "task_done": False,
                   "connected": True, "task": None, "book_channel": "books15"}
    m.groups[2] = {"symbols": {"BUSDT", "CUSDT"}, "created_at_ms": 2, "task_done": False,
                   "connected": True, "task": None, "book_channel": "books"}
    assert m._dedupe_overlapping_groups() == 1
    assert m.groups[2]["symbols"] == {"BUSDT", "CUSDT"}, m.groups[2]["symbols"]
    assert m.groups[1]["symbols"] == {"AUSDT"}
    assert m.groups[1]["pending_release"] == {"BUSDT"}
    assert not m.groups[1].get("task_done"), "sibling symbols must keep their connection"

    ws = FakeWS()
    await m._release_symbol(ws, 1, "BUSDT")
    await m._release_symbol(ws, 1, "BUSDT")
    assert len(ws.sent) == 1 and ws.sent[0]["op"] == "unsubscribe"
    assert {a["channel"] for a in ws.sent[0]["args"]} == {"trade", "books15"}


async def test_resync_forces_snapshot():
    m = sa.OrderFlowManager()
    m.groups[7] = {"symbols": {"AUSDT"}, "created_at_ms": 1, "task_done": False,
                   "connected": True, "task": None, "book_channel": "books"}
    ws = FakeWS()
    await m._resync_symbol(ws, 7, "AUSDT")
    assert [msg["op"] for msg in ws.sent] == ["unsubscribe", "subscribe"], ws.sent
    assert all({a["channel"] for a in msg["args"]} == {"books"} for msg in ws.sent), ws.sent


async def main():
    for test in (test_trade_dedupe, test_sequence_gap_requests_resync, test_channel_tiering,
                 test_ownership_prefers_desired_channel, test_resync_forces_snapshot):
        await test()
        print("ok", test.__name__)


asyncio.run(main())
